package com.school.buttons;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    Button A, B, C, D, E;
    String[] listA = {"393280688888", "393930000114"};
    String[] listB = {"393930023400", "393280688888"};
    String[] listC = {"393930023400", "393930000114"};
//    String[] listD = {"1", "2", "3", "5"};
//    String[] listE = {"1", "2", "3", "4"};
    Random r;
    EditText numberofroom, typeofroom, DateofArrival, DateofDeparture, numberofpeople,
            numberofAdult, numberofchildern,guestphone,guestemail;
    Spinner breakfast, bathroom;
    String BReakfast, Bathroom;
    Calendar myCalendar;
    Button Ok, Cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        A = findViewById(R.id.ButtonA);
        B = findViewById(R.id.ButtonB);
        C = findViewById(R.id.ButtonC);
        D = findViewById(R.id.ButtonD);
        E = findViewById(R.id.ButtonE);
        myCalendar = Calendar.getInstance();

        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

        };
        final DatePickerDialog.OnDateSetListener date2 = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel2();
            }

        };


        A.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                r = new Random();
                final String getNumber = listA[r.nextInt(listA.length)];
                final Dialog dialog = new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.customlayout);
                numberofroom = dialog.findViewById(R.id.numberofroom);
                typeofroom = dialog.findViewById(R.id.typeofroom);
                guestemail=dialog.findViewById(R.id.guestemail);
                guestphone=dialog.findViewById(R.id.guestPhone);
                DateofArrival = dialog.findViewById(R.id.DateofArrival);
                DateofDeparture = dialog.findViewById(R.id.DateofDeparture);
                numberofpeople = dialog.findViewById(R.id.numberofpeople);
                numberofAdult = dialog.findViewById(R.id.numberofAdult);
                numberofchildern = dialog.findViewById(R.id.numberofchildern);
                bathroom = dialog.findViewById(R.id.spinnerbathroom);
                breakfast = dialog.findViewById(R.id.spinnerbreakfast);
                Ok = dialog.findViewById(R.id.Ok);
                Cancel = dialog.findViewById(R.id.Cancel);
                Break_spinner();
                Bathroom_spinner();
                DateofArrival.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        new DatePickerDialog(MainActivity.this, date, myCalendar
                                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                                myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                    }
                });
                DateofDeparture.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        new DatePickerDialog(MainActivity.this, date2, myCalendar
                                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                                myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                    }
                });
                Ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        PackageManager packageManager = MainActivity.this.getPackageManager();
                        Intent i = new Intent(Intent.ACTION_VIEW);

                        try {
                            String url = "https://wa.me/"+getNumber+"?text=" + URLEncoder.encode("Number of rooms: " + numberofroom.getText().toString() + "\n" +
                                    "Type of room: " + typeofroom.getText().toString() + "\n" +
                                    "Date of Arrival: " + DateofArrival.getText().toString() + "\n" +
                                    "Date of Departure: " + DateofDeparture.getText().toString() + "\n" +
                                    "Number of people: " + numberofpeople.getText().toString() + "\n" +
                                    "Guest Phone: " + guestphone.getText().toString() + "\n" +
                                    "Guest Email: " + guestemail.getText().toString() + "\n" +
                                    "Adults: " + numberofAdult.getText().toString() + "\n" +
                                    "Childrens: " + numberofchildern.getText().toString() + "\n" +
                                    "Bathroom: " + Bathroom + "\n" +
                                    "Breakfast : " + BReakfast + "\n", "UTF-8");
                            i.setPackage("com.whatsapp");
                            i.setData(Uri.parse(url));
                            if (i.resolveActivity(packageManager) != null) {
                                MainActivity.this.startActivity(i);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
                Cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                dialog.show();

            }
        });
        B.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                r = new Random();
                final String getNumber = listB[r.nextInt(listB.length)];
                final Dialog dialog = new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.customlayout);
                numberofroom = dialog.findViewById(R.id.numberofroom);
                typeofroom = dialog.findViewById(R.id.typeofroom);
                DateofArrival = dialog.findViewById(R.id.DateofArrival);
                guestemail=dialog.findViewById(R.id.guestemail);
                guestphone=dialog.findViewById(R.id.guestPhone);
                DateofDeparture = dialog.findViewById(R.id.DateofDeparture);
                numberofpeople = dialog.findViewById(R.id.numberofpeople);
                numberofAdult = dialog.findViewById(R.id.numberofAdult);
                numberofchildern = dialog.findViewById(R.id.numberofchildern);
                bathroom = dialog.findViewById(R.id.spinnerbathroom);
                breakfast = dialog.findViewById(R.id.spinnerbreakfast);
                Ok = dialog.findViewById(R.id.Ok);
                Cancel = dialog.findViewById(R.id.Cancel);
                Break_spinner();
                Bathroom_spinner();
                DateofArrival.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        new DatePickerDialog(MainActivity.this, date, myCalendar
                                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                                myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                    }
                });
                DateofDeparture.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        new DatePickerDialog(MainActivity.this, date2, myCalendar
                                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                                myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                    }
                });
                Ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        PackageManager packageManager = MainActivity.this.getPackageManager();
                        Intent i = new Intent(Intent.ACTION_VIEW);

                        try {
                            String url = "https://wa.me/"+getNumber+"?text=" + URLEncoder.encode("Number of rooms: " + numberofroom.getText().toString() + "\n" +
                                    "Type of room: " + typeofroom.getText().toString() + "\n" +
                                    "Date of Arrival: " + DateofArrival.getText().toString() + "\n" +
                                    "Date of Departure: " + DateofDeparture.getText().toString() + "\n" +
                                    "Number of people: " + numberofpeople.getText().toString() + "\n" +
                                    "Guest Phone: " + guestphone.getText().toString() + "\n" +
                                    "Guest Email: " + guestemail.getText().toString() + "\n" +
                                    "Adults: " + numberofAdult.getText().toString() + "\n" +
                                    "Childrens: " + numberofchildern.getText().toString() + "\n" +
                                    "Bathroom: " + Bathroom + "\n" +
                                    "Breakfast : " + BReakfast + "\n", "UTF-8");
                            i.setPackage("com.whatsapp");
                            i.setData(Uri.parse(url));
                            if (i.resolveActivity(packageManager) != null) {
                                MainActivity.this.startActivity(i);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
                Cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                dialog.show();

            }

        });
        C.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                r = new Random();
                final String getNumber = listC[r.nextInt(listC.length)];
                final Dialog dialog = new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.customlayout);
                numberofroom = dialog.findViewById(R.id.numberofroom);
                typeofroom = dialog.findViewById(R.id.typeofroom);
                DateofArrival = dialog.findViewById(R.id.DateofArrival);
                DateofDeparture = dialog.findViewById(R.id.DateofDeparture);
                guestemail=dialog.findViewById(R.id.guestemail);
                guestphone=dialog.findViewById(R.id.guestPhone);
                numberofpeople = dialog.findViewById(R.id.numberofpeople);
                numberofAdult = dialog.findViewById(R.id.numberofAdult);
                numberofchildern = dialog.findViewById(R.id.numberofchildern);
                bathroom = dialog.findViewById(R.id.spinnerbathroom);
                breakfast = dialog.findViewById(R.id.spinnerbreakfast);
                Ok = dialog.findViewById(R.id.Ok);
                Cancel = dialog.findViewById(R.id.Cancel);
                Break_spinner();
                Bathroom_spinner();
                DateofArrival.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        new DatePickerDialog(MainActivity.this, date, myCalendar
                                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                                myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                    }
                });
                DateofDeparture.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        new DatePickerDialog(MainActivity.this, date2, myCalendar
                                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                                myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                    }
                });
                Ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        PackageManager packageManager = MainActivity.this.getPackageManager();
                        Intent i = new Intent(Intent.ACTION_VIEW);

                        try {
                            String url = "https://wa.me/"+getNumber+"?text=" + URLEncoder.encode("Number of rooms: " + numberofroom.getText().toString() + "\n" +
                                    "Type of room: " + typeofroom.getText().toString() + "\n" +
                                    "Date of Arrival: " + DateofArrival.getText().toString() + "\n" +
                                    "Date of Departure: " + DateofDeparture.getText().toString() + "\n" +
                                    "Number of people: " + numberofpeople.getText().toString() + "\n" +
                                    "Guest Phone: " + guestphone.getText().toString() + "\n" +
                                    "Guest Email: " + guestemail.getText().toString() + "\n" +
                                    "Adults: " + numberofAdult.getText().toString() + "\n" +
                                    "Childrens: " + numberofchildern.getText().toString() + "\n" +
                                    "Bathroom: " + Bathroom + "\n" +
                                    "Breakfast : " + BReakfast + "\n", "UTF-8");
                            i.setPackage("com.whatsapp");
                            i.setData(Uri.parse(url));
                            if (i.resolveActivity(packageManager) != null) {
                                MainActivity.this.startActivity(i);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
                Cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                dialog.show();

            }
        });
        D.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                String getNumber = listD[r.nextInt(listA.length)];
//                Toast.makeText(MainActivity.this, getNumber + "", Toast.LENGTH_LONG).show();
            }
        });
        E.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                String getNumber = listE[r.nextInt(listA.length)];
//                Toast.makeText(MainActivity.this, getNumber + "", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void updateLabel() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        DateofArrival.setText(sdf.format(myCalendar.getTime()));

    }

    private void updateLabel2() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        DateofDeparture.setText(sdf.format(myCalendar.getTime()));
    }

    public void Break_spinner() {
        ArrayAdapter<CharSequence> arrayAdapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.breakfast, android.R.layout.simple_spinner_dropdown_item);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        breakfast.setAdapter(arrayAdapter);
        AdapterView.OnItemSelectedListener itemSelectedListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (i != 0) {

                    BReakfast = breakfast.getSelectedItem().toString();

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        };
        breakfast.setOnItemSelectedListener(itemSelectedListener);

    }

    public void Bathroom_spinner() {
        ArrayAdapter<CharSequence> arrayAdapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.bathroom, android.R.layout.simple_spinner_dropdown_item);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        bathroom.setAdapter(arrayAdapter);
        AdapterView.OnItemSelectedListener itemSelectedListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (i != 0) {

                    Bathroom = bathroom.getSelectedItem().toString();

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        };
        bathroom.setOnItemSelectedListener(itemSelectedListener);

    }
}
